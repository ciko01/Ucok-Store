"""Telegram bot starter package."""
